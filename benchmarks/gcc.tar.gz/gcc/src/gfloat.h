#error float.h values not known for cross-compiler
