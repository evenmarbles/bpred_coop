#include "standard.h"

controlf()
{

int feed_length ;

feed_length = countf() ;
configuref( feed_length ) ;
funccost = findcostf() ;

return( feed_length / fdWidth ) ;
}
