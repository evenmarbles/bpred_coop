#include "EXTERN.h"
#include "perl.h"

void boot_DynaLoader(CV* cv){}
